<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Logout</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="logout-container">
        <h2>You have successfully logged out.</h2>
        <button onclick="window.location.href='login.php'">Logout</button>
    </div>
</body>
</html>
